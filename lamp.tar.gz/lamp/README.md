# lamp

LAMP Installer for Ingram Micro Cloud Orchestrator

Installs:

- Apache 2.4
- PHP 7
- MySQL Server 5.6
- Vsftpd
- PHPMyAdmin
