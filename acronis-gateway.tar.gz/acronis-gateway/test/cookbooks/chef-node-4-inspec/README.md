# chef-node-4-inspec
Stores the node on a file on disk for inspec
TODO: Enter the cookbook description here.